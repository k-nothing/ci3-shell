<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['engine'] = 'CI3-shell';
//----------------------------
$lang['el_en']="English language";
$lang['el_de']="Deutsche sprache";
//----------------------------
$lang['wtci'] = "Welcome to CodeIgniter!";
$lang['p1'] = "The page you are looking at is being generated dynamically by CodeIgniter.";
$lang['p2'] = "If you would like to edit this page you'll find it located at:";
$lang['p3'] = "The corresponding controller for this page is found at:";
$lang['p4'] = "If you are exploring CodeIgniter for the very first time, you should start by reading the";
$lang['ug'] = "User Guide";